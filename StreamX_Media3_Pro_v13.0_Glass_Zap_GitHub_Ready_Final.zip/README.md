# StreamX Media3 Pro — 13.0 Glass-Zap (512MB TV)

This source revision is a conservative performance and stability upgrade of the supplied v13.0 4D Glossy Studio project. Existing screens, channel navigation, M3U/Xtream profiles, encrypted credentials, EPG, favorites, recents, search, channel logos, boot overlay, and the layered glass/3D icon assets are retained.

## v13.0 changes
- Removed `largeHeap` so Android can manage the app within the device's normal memory budget; requesting a larger Java heap is not the same as making a 512MB TV faster.
- Disabled optional Media3 extension decoders to avoid loading extra decoder libraries on low-RAM TVs. Platform decoder fallback remains enabled.
- Tuned the 512MB buffer profile to a more realistic 250ms start threshold, 650ms rebuffer threshold, and 3.5MiB target allocator budget. Extremely tiny buffer thresholds do not bypass HLS segment/network latency and can increase stalls.
- Reduced speculative prefetch to the next channel only. Removed the recent/favorite top-eight warmup that could compete with the currently playing stream.
- Bound each speculative socket warmup to 1.8 seconds and a 128-byte range read without changing the shared playback client's timeout.
- Preserved the existing TV remote/D-pad UI and glossy layered 3D/“4D” visual assets rather than adding blur-heavy effects that could increase GPU cost on a low-end TV.
- Repaired the GitHub Actions workflow to find and extract the uploaded source ZIP, install Android SDK 36, run verification and unit tests, then produce one release APK artifact.

## Compatibility and build
- Minimum Android: 6.0 / API 23 (Media3 1.11.1 baseline).
- Compile SDK 36; target SDK 34.
- JDK 17, Android Gradle Plugin 8.13.2, Gradle 8.13, Kotlin 2.2.20.
- Open the `iptv_media3_pro_android_tv` folder in Android Studio, sync, run `testDebugUnitTest`, then `assembleRelease`.

## Important performance note
A 0.05-second playlist restore or channel change cannot be guaranteed. Cached channel metadata can sometimes be restored quickly, but actual live video startup depends on provider response time, playlist/segment duration, network latency, codec/decoder support, and TV firmware. No source-code change can guarantee zero buffering or zero lag on every 512MB TV. Test with authorized streams on the actual TV.

## GitHub Actions
The workflow is included at `.github/workflows/build_apk.yml` inside the project. If the repository contains only the ZIP file, create a workflow in the repository's root `.github/workflows/build_apk.yml` using the separate YAML provided with this archive; GitHub does not automatically activate a workflow stored inside an unextracted ZIP.

## Security and lawful use
Only use playlist URLs, EPG feeds and Xtream credentials you are authorized to access. HTTP playlist support remains for providers that do not offer HTTPS; prefer HTTPS where available.

## App update/signing note
Android only permits an in-place app update when the APK uses the same signing key as the installed version. The GitHub workflow supports a persistent keystore through repository Actions secrets. If the prior build used a temporary runner-only debug key and that exact key is unavailable, uninstalling the previous app will be required before installing this build, and uninstalling clears local app data.
